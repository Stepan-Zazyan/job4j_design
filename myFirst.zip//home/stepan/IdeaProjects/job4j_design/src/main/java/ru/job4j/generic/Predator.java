package ru.job4j.generic;

public class Predator extends Animal {
}
