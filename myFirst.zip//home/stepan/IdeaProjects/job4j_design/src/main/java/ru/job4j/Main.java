package ru.job4j;

import ru.job4j.collection.SimpleArrayList;
import ru.job4j.io.SearchFiles;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) throws IOException {
/*        SimpleArrayList<Integer> sq = new SimpleArrayList<>(0);
        sq.add(1);
        int a = 1023 << 22;
        System.out.println(Objects.hash(a));
        System.out.println(Objects.toString(null, "this object is null"));
        PhoneNum num = new PhoneNum((short) 25, 11, "(short) ");
        int code = num.hashCode();
        int[] ar = {1, 2, 3, 4, 5};
        for (int i = 0; i < ar.length; i++) {
            System.out.println(ar[i++]);
        }
        int i = Objects.hash(sq.hashCode()) & (153434 - 1);
        Optional<SimpleArrayList<Integer>> opt = Optional.of(sq);
        Optional<SimpleArrayList<Integer>> opt2 = Optional.of(sq);
        System.out.println(Objects.equals(opt, opt2));
        int q = 5;
        Main main = new Main();
        Predicate<Integer> predicate = s -> s == 5;
        boolean rsl = main.methodPredicate(q, predicate);
        System.out.println("Предикат = " + rsl);
        Object obj = new Object();
        Set<Integer> setOrig = new HashSet<>(Set.of(1, 2, 3, 4, 5));
        Set<Integer> second = new HashSet<>(Set.of(1, 2, 3));
        *//*boolean shit = setOrig.remove(6);*//*
        setOrig.retainAll(second);
        System.out.println(setOrig);
        Stack<Integer> stack = new Stack<>();
        System.out.println(stack.getClass());
        stack.push(1);
        stack.push(2);
        stack.push(3);
        System.out.println(stack.pop());
        System.out.println(stack);

        ArrayDeque<Integer> queue = new ArrayDeque<>();
        queue.push(1);
        queue.push(2);
        queue.push(3);
        queue.poll();
        System.out.println(queue);
        String s = "Hello=world";
        String blank = "               ";
        String[] start = s.split("=");
        System.out.println(Arrays.toString(start));
        System.out.println(blank.isBlank());
        System.out.println(blank.isEmpty());
        Path root = Paths.get("Tiger");
        SearchFiles searcher = new SearchFiles(p -> p.toFile().getName().endsWith("Tiger"));
        Path paths = Files.walkFileTree(root, searcher);
        System.out.println(paths);*/
        System.out.println(Math.round((float) 8790 / 100));
        String str = "Ales";
        String cutted = str.substring(1);
        System.out.println(cutted);
        Path s = Path.of("/home/stepan/IdeaProjects/job4j_design/Search.java");
        File file = new File("/home/stepan/IdeaProjects/job4j_design");
        String q = file.getPath();
        if (!file.exists()) {
            throw new IllegalArgumentException(String.format("Not exist %s", file.getAbsoluteFile()));
        }
        System.out.println(file);
        System.out.println(s.toFile().getName());
        System.out.println(s.toAbsolutePath());
        System.out.println(s.toFile().getName().endsWith(".java"));
        System.out.println(s.toAbsolutePath().endsWith(".java"));
    }

    private static class PhoneNum {

        Short lineNum;
        int prefix;
        String areaCode;

        public PhoneNum(Short lineNum, int prefix, String areaCode) {
            this.lineNum = lineNum;
            this.prefix = prefix;
            this.areaCode = areaCode;
        }

    }

    public boolean methodPredicate(int a, Predicate<Integer> pr) {
        boolean rsl = false;
        if (pr.test(a)) {
            rsl = true;
        }
        return rsl;
    }
}
