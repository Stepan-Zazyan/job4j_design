package ru.job4j.generic;

public class Animal {
}
