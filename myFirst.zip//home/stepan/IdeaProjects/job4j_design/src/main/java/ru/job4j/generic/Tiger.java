package ru.job4j.generic;

public class Tiger extends Predator {
}
